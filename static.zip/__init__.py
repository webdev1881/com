# -*- coding: utf-8 -*-
"""
Модуль интеграции Vue.js 3 с Odoo 18
"""

from . import controllers
